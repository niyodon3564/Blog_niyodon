<?php
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}
/*
 * @Author:    niyodon
 *  email:     niyodonpaci@gmail.com
 * github:     https://github.com/niyodon
 */

class Model_niyodon extends CI_Model{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
  }

// ======== crud =========
  public function create($table,$data){
    $sql=$this->db->insert($table,$data);
    return $sql ;
  }

  public function getList($table,$condition = array()){
    if(!empty($condition)){
      $this->db->where($condition);
    }
		$sql=$this->db->get($table) ;

    return $sql->result_array() ;
	}

  public function getOne($table,$where){
    $this->db->where($where) ;
    $sql=$this->db->get($table) ;
    return $sql->row_array() ;
  }

   public function update($table, $criteres, $data) {
      $this->db->where($criteres);
      $query = $this->db->update($table, $data);
      return ($query) ? true : false;
    }

  public function delete($table,$where){
     $this->db->where($where);
     $sql=$this->db->delete($table) ;
     return $sql;
   }

   public function getRequeteOne($requete){
     $query=$this->db->query($requete);
     if ($query) {
      return $query->row_array();
    }
  }

  public function getRequete($requete){
         $query=$this->db->query($requete);
         if ($query) {
          return $query->result_array();
        }
      }

  function getListOrder($table,$criteres)
  {
    $this->db->order_by($criteres);
    $query= $this->db->get($table);
    if($query)
    {
      return $query->result_array();
    }
  }
function insert_batch($table,$data){

    $query=$this->db->insert_batch($table, $data);
    return ($query) ? true : false;
    //return ($query)? true:false;

}

  public function insert_last_id($table, $data) {
    $query = $this->db->insert($table, $data);

    if ($query) {
      return $this->db->insert_id();
    }
  }


  public function countAll($table)
    {
        return $this->db->count_all_results($table);
    }




    public function maker($requete)//make query
    {
      return $this->db->query($requete);
    }

    public function datatable($requete)//make_datatables : requete avec Condition,LIMIT start,length
    { 
        $query =$this->maker($requete);//call function make query
        return $query->result();
    }  
    public function all_data($requete)//count_all_data : requete sans Condition sans LIMIT start,length
    {
       $query =$this->maker($requete); //call function make query
       return $query->num_rows();
     }
     public function filtrer($requete)//get_filtered_data : requete avec Condition sans LIMIT start,length
     {
         $query =$this->maker($requete);//call function make query
         return $query->num_rows();

       }

       
      function getRequete_object($requete){
       $query=$this->db->query($requete);
       if ($query) {
        return $query->result();
      }
    }







 
//pacy
public function mois($moi=0){
            $moislettre='';
            if($moi==1)
                $moislettre='Janvier';
            if($moi==2)
                $moislettre='Février';
            if($moi==3)
                $moislettre='Mars';
            if($moi==4)
                $moislettre='Avril';
            if($moi==5)
                $moislettre='Mai';
            if($moi==6)
                $moislettre='Juin';
            if($moi==7)
                $moislettre='Juillet';
            if($moi==8)
                $moislettre='Août';
            if($moi==9)
                $moislettre='Septembre';
            if($moi==10)
                $moislettre='Octobre';
            if($moi==11)
                $moislettre='Novembre';
            if($moi==12)
                $moislettre='Décembre';

            return $moislettre;
        }









}
