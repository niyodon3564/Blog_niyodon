<?php

/*
 * @Author:    niyodon
 *  email:     niyodonpaci@gmail.com
 * github:     https://github.com/niyodon
 */
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Home extends My_Controller
{
	
	function __construct()
	{
	   parent::__construct();
	}

	public function index(){
	 $this->load->view('template/home');
	}

	public function fetch_data(){

$articles=$this->Model_niyodon->getList('articles');
		$out_put='';
         foreach ($articles as $value) {  
$total_like=$this->Model_niyodon->getRequeteOne('SELECT SUM(total_like) as total FROM likes WHERE id_for_article='.$value['id'].'') ; 

$total_comment=$this->Model_niyodon->getRequeteOne('SELECT COUNT(*) as total FROM comments WHERE id_for_article='.$value['id'].'') ;   

$out_put.='<div class="col-md-4">
       <div class="card">
        <img src="'.base_url('attachments/article_images/').$value['image'].'" alt="" style="height:200px; width:150;">
        <div class="card-body">
          <h4 class="card-title text-center"><strong>'.$value['title'].'</strong></h4>
          <p class="card-text">'.$value['basic_description'].'</p>
        </div>
        <div class="card-footer">
          <ul class="pager">
            <li class="next pull-left">
              <a href="'.base_url('Home/detail/').$value['id'].'">Detail</a><br>
            </li>
            <li class="next pull-left">
              <a href="#" data-toggle="modal" data-target="#like_'.$value['id'].'"><i class="fa fa-heart like" style="color: red;"></i>
              	<span id="total">'.
                     $total_like['total']
              	.'</span>
              </a><br>
            </li>
            <li class="next pull-left">
              <a href="#" data-toggle="modal" data-target="#comment_'.$value['id'].'">
              Comments <span class="text-danger">'.$total_comment['total'].'</span>
              </a><br>
            </li>
          </ul>
        </div>
       </div>
    </div>


<div class="modal fade" id="comment_'.$value['id'].'" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Your email & comment please</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="col-md-12">
          <label>Email</label>
          <input type="email" id="email_com_'.$value['id'].'" class="form-control" name="email" placeholder="your email here">
          <font class="text-danger email_error"></font>
        </div>
        <div class="col-md-12">
          <label>Comment</label>
          <input type="text" class="form-control" id="comments_'.$value['id'].'" name="comment" placeholder="your comment here">
          <font class="text-danger comment_error"></font>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-primary"onclick="save_com('.$value['id'].')">Save</button>
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="like_'.$value['id'].'" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Your email please</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="col-md-12">
          <input type="text" class="form-control" id="email_'.$value['id'].'" name="email" placeholder="your email here">
        </div>
        <font class="text-danger email_error"></font>
      </div>
      <div class="modal-footer">
        <button type="button" id="'.$value['id'].'" class="btn btn-outline-primary " onclick="update_data('.$value['id'].')">
            Save
        </button>
      </div>
    </div>
  </div>
</div>';


     } 
  echo $out_put;
}

	public function save_like(){
	$id_for_article=$this->input->post('id_for_article');
    $email=$this->input->post('email');

    $autorisation=$this->Model_niyodon->getRequeteOne("SELECT * FROM likes WHERE user_name='".$email."' and id_for_article=".$id_for_article."");
    
    $total_like=1;

    if (empty($autorisation)) {

      $this->db->query("insert into likes(total_like,id_for_article,user_name) values('".$total_like."','".$id_for_article."','".$email."')");
      echo 1;
    }
    else{
      echo 0;
    }
 }


	public function save_comment(){

    $id_for_article=$this->input->post('id_for_article');
    $user=$this->input->post('email');
    $comment=$this->input->post('comment');

    $autorisation=$this->Model_niyodon->getRequeteOne("select count(id_for_article) as total, email from comments where email='".$user."' and id_for_article=".$id_for_article."");
    

    if ($autorisation['total']<3) {

      $this->db->query("insert into comments(email,comment,id_for_article) values('".$user."','".$comment."','".$id_for_article."')");
     echo 1;
    }
    else{
      echo 0;
    }
  }

  public function detail($id){

$total_like=$this->Model_niyodon->getRequeteOne('SELECT SUM(total_like) as total FROM likes WHERE id_for_article='.$id.'') ; 

$total_comment=$this->Model_niyodon->getRequeteOne('SELECT COUNT(*) as total FROM comments WHERE id_for_article='.$id.'') ;
$article=$this->Model_niyodon->getRequeteOne('
          SELECT
              a.*,
              c.categorie_id,
              c.categorie_descr
          FROM
              articles a
          JOIN categories c ON
              c.categorie_id = a.id_for_categories
          WHERE id='.$id.'') ;
    $data['article']=$article;
    $data['comment']=$total_comment['total'];
    $data['like']=$total_like['total'];
  	$data['title']='Detail for '.$article['title'];
  	$this->load->view('template/detail_view',$data);
  }


}