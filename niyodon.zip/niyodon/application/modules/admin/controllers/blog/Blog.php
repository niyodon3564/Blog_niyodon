<?php

/*
 * @Author:    niyodon
 *  email:     niyodonpaci@gmail.com
 * github:     https://github.com/niyodon
 */
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Blog extends My_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        // $this->login_check();
      $data['categories']=$this->Model_niyodon->getList('categories');
      $data['title']='List of articles';
      $this->load->view('blog/blog_list_view',$data);

    }


####################### add new article ###############


  public function add_new_view(){
    $data['title']='New prublication';
    $data['categories']=$this->Model_niyodon->getList('categories');
    if (isset($_POST['btn-publish'])) {
        $this->add_article();
     }
    $this->load->view('blog/blog_add_view',$data);
  }

  public function add_article(){
$this->form_validation->set_rules('categorie','category','required');
$this->form_validation->set_rules('title','title','required');
$this->form_validation->set_rules('description','description','required');

if ($this->form_validation->run()!=FALSE) {

$categorie=$this->input->post('categorie');
$folder=$this->input->post('folder');
$title=$this->input->post('title');
$description=$this->input->post('description');
$basic_description=$this->input->post('basic_description');
$image_name=$this->upload_document($_FILES['image']['tmp_name'],$_FILES['image']['name']);

$data=array('image' => $image_name,
            'id_for_categories' => $categorie,
            'title' => $title,
            'description' => $description,
            'basic_description' => $basic_description,
            'folder'=>$folder
            );

$resp=$this->Model_niyodon->insert_last_id('articles',$data);

if ($resp) {

 $sms['sms']='<div class="row" id="message" >
                <div class="alert alert-success text-center col-md-12">
                  <strong> Oup! </strong>
                  Produit publié avec succès .
                </div>
              </div>' ;
}else{
 $sms['sms']='div class="row" id="message" >
                <div class="alert alert-danger text-center col-md-12">
                  <strong> Oup! </strong>
                  Une erreur s\'est produite !
                </div>
              </div>' ;
}

$this->session->set_flashdata($sms) ;
redirect(base_url('admin/liste_article'));
} else {
  $this->add_new_view();
}


  }

  //upload images
public function upload_document($nom_file,$nom_champ)
{
      $ref_folder =FCPATH.'attachments/article_images/';
      $code=date("YmdHis").uniqid();
      $fichier=basename($code);
      $file_extension = pathinfo($nom_champ, PATHINFO_EXTENSION);
      $file_extension = strtolower($file_extension);
      $valid_ext = array('gif','jpg','png','jpeg','JPG','PNG','JPEG');

      if(!is_dir($ref_folder)) //create the folder if it does not already exists   
      {
          mkdir($ref_folder,0777,TRUE);
                                                     
      }  
      move_uploaded_file($nom_file, $ref_folder.$fichier.".".$file_extension);
      $image_name=$fichier.".".$file_extension;
      return $image_name;
}


    private function uploadImage()
    {

    $config['upload_path'] = './attachments/article_images/';
    $config['allowed_types'] ='gif|jpg|png|jpeg|JPG|PNG|JPEG';
    $this->load->library('upload', $config);
    $this->upload->initialize($config);
    if (!$this->upload->do_upload('userfile')) {
        log_message('error', 'Image Upload Error: ' . $this->upload->display_errors());
    }
    $img = $this->upload->data();
    return $img['file_name'];
    }

###############<! end add_new article >############


###############< edit article >##############

public function edit_article_view($id){
  $article=null;
      if ($id>0) {
        $article=$this->Model_niyodon->getRequeteOne('
          SELECT
              a.*,
              c.categorie_id,
              c.categorie_descr
          FROM
              articles a
          JOIN categories c ON
              c.categorie_id = a.id_for_categories
          WHERE id='.$id.'') ;

      }
      $data['title']='Modification';
      $_POST['folder']=$article['folder'];
      $data['categories']=$this->Model_niyodon->getRequete('select * from categories');
      // $data['otherImgs'] = $this->loadOthersImages();
      $data['article']=$article;
      if (isset($_POST['btn-publish_modif'])) {
        $this->update_article();
     }
      $this->load->view('blog/blog_update_view',$data);
}


  public function update_article(){

if (!empty($_FILES['image']['name'])) {
$image_name=$this->upload_document($_FILES['image']['tmp_name'],$_FILES['image']['name']);
} else {
  $image_name=$this->input->post('hidden_image');
}

$id_article=$this->input->post('id_article');
$categorie=$this->input->post('categorie');
$folder=$this->input->post('folder');
$title=$this->input->post('title');
$description=$this->input->post('description');
$basic_description=$this->input->post('basic_description');

$data=array('image' => $image_name,
            'id_for_categories' => $categorie,
            'title' => $title,
            'description' => $description,
            'basic_description' => $basic_description,
            'folder'=>$folder,
            'time_update' => date("Y-m-d h:i:s")
            );

$resp=$this->Model_niyodon->update('articles',['id'=>$id_article],$data);


if($resp){
 $sms['sms']='<div class="row" id="message" >
                <div class="alert alert-success text-center col-md-12">
                  <strong> Oup! </strong>
                  Article updated successful .
                </div>
              </div>' ;
           }else{
 $sms['sms']='div class="row" id="message" >
                <div class="alert alert-danger text-center col-md-12">
                  <strong> Oup! </strong>
                  An error occured !
                </div>
              </div>' ;
}

$this->session->set_flashdata($sms) ;
redirect(base_url('admin/liste_article'));

  }


############<! end edit_product >##############

public function delete_product($id){
  $rps=$this->Model_niyodon->delete('articles',['id'=>$id]);
  if ($rps) {
    $sms['sms']='<div class="row" id="message" >
                <div class="alert alert-success text-center col-md-12">
                  <strong> Oup! </strong>
                  Article deleted successful .
                </div>
              </div>' ;
    $this->session->set_flashdata($sms);
    redirect(base_url('admin/liste_article'));
  }
}
public function getBlogs($critaire=null){

$var_search = !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;
  $limit=" LIMIT 0,10";
  $var_search=str_replace("'", "\'", $var_search);  
  $query_principal="
    SELECT
    a.*,
    c.categorie_id,
    c.categorie_descr
FROM
    articles a
JOIN categories c ON
    c.categorie_id = a.id_for_categories";

  $critaire="";

  $order_by='';
  if($_POST['order']['0']['column']!=0){
        $order_by = isset($_POST['order']) ? ' ORDER BY '.$_POST['order']['0']['column'] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY id DESC';
      }

  $limit='LIMIT 0,10';
      if($_POST['length'] != -1){
        $limit='LIMIT '.$_POST["start"].','.$_POST["length"];
      }

$search = !empty($_POST['search']['value']) ? (" AND (title LIKE '%$var_search%' OR  basic_description LIKE '%$var_search%' OR  description LIKE '%$var_search%' OR categorie_descr LIKE '%$var_search%')") : '';


$grp="";
$query_secondaire=$query_principal.' '.$critaire.''.$search.''.$grp.''.$order_by.''.$limit;
$query_filter=$query_principal.''.$critaire.''.$search.''.$grp;

$fetch_all_pubs = $this->Model_niyodon->datatable($query_secondaire);
$u=0;
$data = array();
foreach ($fetch_all_pubs as $row) {

$image='<a class="venobox" data-gall="myGallery" href="'.base_url().'attachments/article_images/'. $row->image.'">
    <img src="'.base_url().'attachments/article_images/'. $row->image.'"  id="pub_carousel_img" style="height:100px;" alt="image alt"/>
</a>' ;
           $u++;
           $all_pubs = array();
           $all_pubs[] =  $u;
           $all_pubs[]=$image;
           $all_pubs[]=$row->title;
           $all_pubs[]=$row->categorie_descr;
           $all_pubs[]=$row->basic_description;
           $all_pubs[]=$row->description;
           $all_pubs[]=$row->time;


$opt='<div class="dropdown">
           <a class="btn btn-outline-primary btn-sm dropdown-toggle" data-toggle="dropdown">
           <i class="fa fa-cog"></i> Options<span class="caret">
           </span></a> 
           <ul class="dropdown-menu dropdown-menu-left">';

$opt.='<li><a href="'.base_url('admin/blog/Blog/edit_article_view/'.$row->id).'" class="ml-2"> Modifier</a></li>
       <li><a href="#" class="ml-2 text-danger" data-toggle="modal" data-target="#delete'.$row->id.'">
           Supprimer
           </a>
       </li>';
$opt.='</ul>';

$opt.='<div class="modal fade" id="delete'.$row->id.'">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span class="text-danger" aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="'.base_url("admin/blog/Blog/delete_product/".$row->id).'" method="post">
        <div class="modal-body">
          <h6>Voulez vraiement supprimer ce produit <strong>'.$row->title.'</stronger> ?
          </h6>
        </div>
        <div class="modal-footer float-right">
          <button type="submit" class="btn btn-outline-danger">Supprimer</button>
        </div>
        </form>
      </div>
    </div>
  </div>';

      $all_pubs[]=$opt;
      $data[] = $all_pubs;

    }

    $output = array(
     "draw" => intval($_POST['draw']),
     "recordsTotal" =>$this->Model_niyodon->all_data($query_secondaire),
     "recordsFiltered" => $this->Model_niyodon->filtrer($query_filter),
     "data" => $data
    );
    echo json_encode($output);
}




}

