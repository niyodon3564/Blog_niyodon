<?php
 include('include/Admin_Header.php') ; 
 ?>    
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Articles</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Admin</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
<section class="content mb-3">



<hr>

<div class="card">
  <div class="container-fluid">
<div class="card-header col-md-12">
  <a href="<?=base_url('admin/nouveau_article')?>" class="btn btn-outline-info float-right">
    <i class="fa fa-plus"></i> New
  </a>
  <h3><?=$title?></h3>
  <?php
      if (!empty($this->session->flashdata('sms'))) {
        echo $this->session->flashdata('sms');
      }
?>
</div>


<div class="table-responsive mt-2">
<table class="table table-bordered" id="mytable">
    <thead>
        <tr>
        	<th>#</th>
            <th>Image</th>
            <th>Titles</th>
            <th>Categories</th>
            <th>Basic description</th>
            <th>Details</th>
            <th>Time</th>
            <th class="text-right">Action</th>
        </tr>
    </thead>
    
 </table>
</div>
	
  </div>	
</div>




</section>





<?php include('include/Admin_Footer.php') ; ?>

<script type="text/javascript">
  $(document).ready(function(){ 
     $("#message").delay("slow").fadeOut(3000);
    get_list();


  });
  function get_list(ID) {
  // body...
    var critaire=ID;

    var row_count ="1000000";

   $("#mytable").DataTable({
        "processing":true,
        "destroy" : true,
       "serverSide":true,
        "oreder":[[ 0, 'desc' ]],
        "ajax":{
            url:"<?=base_url()?>admin/blog/Blog/getBlogs",
            type:"POST",
            data : {
               
               critaire:critaire,


            }
        },
        lengthMenu: [[10,50, 100, row_count], [10,50, 100, "All"]],
    pageLength: 10,
        "columnDefs":[{
            "targets":[],
            "orderable":false
        }],

                  dom: 'Bfrtlip',
    buttons: [
        'copy', 'csv', 'excel', 'pdf', 'print'
    ],
       language: {
                "sProcessing":     "Traitement en cours...",
                "sSearch":         "Rechercher&nbsp;:",
                "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
                "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                "sInfoPostFix":    "",
                "sLoadingRecords": "Chargement en cours...",
                "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
                "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
                "oPaginate": {
                  "sFirst":      "Premier",
                  "sPrevious":   "Pr&eacute;c&eacute;dent",
                  "sNext":       "Suivant",
                  "sLast":       "Dernier"
                },
                "oAria": {
                  "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
                  "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                }
            }
              
    });
}
</script>
