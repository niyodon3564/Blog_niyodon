<?php
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}
 include('include/Admin_Header.php') ; 
 $timeNow = time();
?>


  <!-- Content Wrapper. Contains page content -->
  <!-- <div class="content-wrapper"> -->
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1> Publish article</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Admin</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
<section class="content mb-3 card">
<div class="card-header col-md-12">
  <a href="<?=base_url('admin/liste_article')?>" class="btn btn-outline-info float-right">
    <i class="fa fa-list"></i> List
  </a>
  <h3><?=$title?></h3>
</div>


<form method="POST" action="" enctype="multipart/form-data">
    <input type="hidden" value="<?= isset($_POST['folder']) ? htmlspecialchars($_POST['folder']) : $timeNow ?>" name="folder">

<input type="hidden" value="<?=$article['id']?>" name="id_article">

<div class="pt-3 mr-3 ml-3">
<div class="row mb-3">
    <div class="col-6">
      <div class="form-group">
        <label>Title :</label>
        <input type="text" class="form-control" id="title" name="title" value="<?= $article['title']!=null?$article['title']:''?>" />
      </div>
    </div>
    <div class="col-6">
      <div class="form-group">
        <label>Categorie :</label>
        <select class="form-control" name="categorie">
          <option value="">Select</option>
<?php  foreach ($categories as $value) {  
          if (set_value('categorie')==$value['categorie_id']|| $article['categorie_id']==$value['categorie_id']) { ?>
            <option selected value="<?= $value['categorie_id']?>">
            <?= $value['categorie_descr']?>
          </option>
<?php     } else {  ?>
            <option value="<?= $value['categorie_id']?>">
            <?= $value['categorie_descr']?>
          </option>
<?php    }
          
     } ?>
        </select>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-md-12">
      <div class="form-group">
        <a href="#showSliderDescrption" class="btn btn-outline-info showSliderDescrption accordion-toggle" data-toggle="collapse" data-parent="#showSliderDescrption">Show Slider Description <span class="fa fa-circle-arrow-down"></span></a>
      </div>
    </div>
  </div>

  <div class="col-md-12 collapse" id="showSliderDescrption"  <?= $article['basic_description']!=''?'style="display:block;"':''?>>
      <div class="card card-outline card-info">
        <div class="card-header">
          <h3 class="card-title">
            Basic Description
          </h3>
        </div>
        <div class="card-body">
          <textarea id="summernote2" name="basic_description">
           <?= $article['basic_description']!=''?$article['basic_description']:''?> 
          </textarea>
        </div>
      </div>
  </div>

  <div class="row">
    <div class="col-md-12">
      <label>Description</label>
      <div class="card card-outline card-info">
        <div class="card-header">
          <h3 class="card-title">
            Description
          </h3>
        </div>
        <div class="card-body">
          <textarea id="summernote" name="description">
            <?=$article['description']!=''?$article['description']:''?>
          </textarea>
        </div>
      </div>
    </div>
  </div>

  <div class="row">
  <?php  if (!empty($article['image'])) { 
$image = 'attachments/article_images/'.$article['image'];
    ?>
    <p>Curent image</p>
      <div class="col-md-12">
        <img src="<?= base_url().$image ?>" class="img-responsive img-thumbnail" style="max-width:300px; margin-bottom: 5px;">
      </div>
<?php  } else { 
      echo "no image found";
    }
  

  ?>
    <div class="col-12">
      <div class="form-group">
        <label>Cover Image</label>
        <input type="file" class="form-control" id="image" name="image" placeholder="Image....."/>
        <input type="hidden" value="<?=$article['image']?>" name="hidden_image"/>
      </div>
    </div>
  </div>
  
<!--   <div class="row form-group bordered-group">
    <div class="others-images-container">
       <?= $otherImgs ?>
    </div>
  </div> -->

  <div class="row">
    <div class="col-md-6 offset-3 mb-3">
      <button type="submit" name="btn-publish_modif" class="btn btn-sm btn-outline-info form-control">Update</button>
    </div>
  </div>
</div>
 </form> 

</section>
    






<?php include('include/Admin_Footer.php') ; ?>




<!-- ===========< admin >=============== -->
<script>
$('#message').delay('slow').fadeOut(3000);

    var urls = {
        changePass: '<?= base_url('admin/changePass') ?>',
        editShopCategorie: '<?= base_url('admin/editshopcategorie') ?>',
        changeTextualPageStatus: '<?= base_url('admin/changePageStatus') ?>',
        removeSecondaryImage: '<?= base_url('admin/removeSecondaryImage') ?>',
        productstatusChange: '<?= base_url('admin/productstatusChange') ?>',
        productsOrderBy: '<?= base_url('admin/products?orderby=') ?>',
        productStatusChange: '<?= base_url('admin/productStatusChange') ?>',
        changeOrdersOrderStatus: '<?= base_url('admin/changeOrdersOrderStatus') ?>',
        ordersOrderBy: '<?= base_url('admin/orders?order_by=') ?>',
        uploadOthersImages: '<?= base_url('admin/uploadOthersImages') ?>',
        loadOthersImages: '<?= base_url('admin/loadOthersImages') ?>',
        editPositionCategorie: '<?= base_url('admin/changePosition') ?>'
    };
</script>
<script src="<?= base_url('assets/js/mine_admin.js') ?>"></script>
<!-- ================================================= -->
