<?php

  include VIEWPATH.'template/include/Admin_Header.php'

?>

<style type="text/css">
	.navbar {		
		background: #fff;
		padding-left: 16px;
		padding-right: 16px;
		border-bottom: 1px solid #d6d6d6;
		box-shadow: 0 0 4px rgba(0,0,0,.1);
	}
</style>

</head> 
<body>
<nav class="navbar navbar-default navbar-expand-xl navbar-light">
	<div class="navbar-header d-flex col">
		<a class="navbar-brand" href="#"><i class="fa fa-cube"></i>Blog <b>niyodon</b></a>  		
		<button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle navbar-toggler ml-auto">
			<span class="navbar-toggler-icon"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
	</div>
	<!-- Collection of nav links, forms, and other content for toggling -->
	<div id="navbarCollapse" class="collapse navbar-collapse justify-content-start">
		<ul class="nav navbar-nav">
			<li class="nav-item active"><a href="<?= base_url()?>" class="nav-link">Home</a></li>
			<li class="nav-item"><a href="#" class="nav-link">About</a></li>
			<li class="nav-item"><a href="#" class="nav-link">Blog</a></li>
			<li class="nav-item"><a href="#" class="nav-link">Contact</a></li>
		</ul>
	</div>
</nav>



<!-- ####################< content >################# -->
<div class="conainer">
  <div class="col-md-12">
  	<h2 class="text-center mb-5"><?= $title?></h2><hr>
  </div>
  <div class="row col-md-12">
    <div class="col-md-6">
       <div class="card">
        <div class="card-body">
          <img src="<?= base_url()?>/attachments/article_images/<?= $article['image'];?>" alt="" style="height:500px; width:100%;">
        </div>
       </div>
    </div>
    <div class="col-md-6">
      <div class="row">
        <label class="mr-3">Title:</label>
       <h4 class="card-title text-center"><?= $article['title'];?></h4> 
      </div><hr><br>
      <div class="row">
        <label class="mr-3">Basic description:</label>
        <p class="card-text"><?= $article['basic_description'];?></p> 
      </div><hr><br>
      <div class="row">
        <label class="mr-3">Description:</label>
        <p class="card-text"><?= $article['description'];?></p> 
      </div><hr><br>
      <div class="row">
        <label class="mr-3">Comment:</label>
        <p class="card-text"><?= $comment;?></p> 
      </div><hr><br>
      <div class="row">
        <label class="mr-3">Like:</label>
        <p class="card-text"><?= $like;?></p> 
      </div>
    </div>
  </div>
</div>
</body>
</html>




<!-- jQuery -->
<script src="<?= base_url()?>assets/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?= base_url()?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?= base_url()?>assets/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?= base_url()?>assets/dist/js/demo.js"></script>



                                                     