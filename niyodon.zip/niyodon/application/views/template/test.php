
<!-- <link href="https://fonts.googleapis.com/css?family=Merienda+One" rel="stylesheet">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->

<?php

  include VIEWPATH.'template/include/Admin_Header.php'

?>

<style type="text/css">
	.navbar {		
		background: #fff;
		padding-left: 16px;
		padding-right: 16px;
		border-bottom: 1px solid #d6d6d6;
		box-shadow: 0 0 4px rgba(0,0,0,.1);
	}
</style>

</head> 
<body>
<nav class="navbar navbar-default navbar-expand-xl navbar-light">
	<div class="navbar-header d-flex col">
		<a class="navbar-brand" href="#"><i class="fa fa-cube"></i>Blog <b>niyodon</b></a>  		
		<button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle navbar-toggler ml-auto">
			<span class="navbar-toggler-icon"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
	</div>
	<!-- Collection of nav links, forms, and other content for toggling -->
	<div id="navbarCollapse" class="collapse navbar-collapse justify-content-start">
		<ul class="nav navbar-nav">
			<li class="nav-item active"><a href="#" class="nav-link">Home</a></li>
			<li class="nav-item"><a href="#" class="nav-link">About</a></li>
			<li class="nav-item"><a href="#" class="nav-link">Blog</a></li>
			<li class="nav-item"><a href="#" class="nav-link">Contact</a></li>
		</ul>
	</div>
</nav>



<!-- ####################< content >################# -->
<div class="conainer">
  <div class="col-md-12" id="message_like" style="display:none;">
  	<div class="alert alert-danger text-center" id ="message">vous ne pouvez pas aimer plus de une fois sur le meme article.</div>
  </div>
  <div class="row col-md-12">
  	<?php $nb=count($articles) ;?>
  	<input type="hidden" id="all_article" value="<?=$nb?>">
<?php $i=0;
         foreach ($articles as $value) {             ?>
    <div class="col-md-4">
       <div class="card">
        <img src="<?= base_url()?>/attachments/article_images/<?= $value['image'];?>" alt="" style="height:200px; width:200;">
        <div class="card-body">
          <input type="hidden" id="hidden_data_<?=$i?>" value="<?=$value['id']?>">
          <!-- <script>get_like($value['id'])</script> -->
          <h4 class="card-title text-center"><?= $value['title'];?></h4>
          <p class="card-text"><?= $value['basic_description'];?></p>
        </div>
        <div class="card-footer">
          <ul class="pager">
            <li class="next pull-left">
              <a href="<?= base_url('Home/detail/').$value['id'];?>">Plus &rarr;</a><br>
            </li>
            <li class="next pull-left">
              <a href="#" data-toggle="modal" data-target="#like_<?=$value['id']?>"><i class="fa fa-heart like" style="color: red;"></i>
              	<span id="total_like"></span>
              </a><br>
            </li>
            <li class="next pull-left">
              <a href="#" data-toggle="modal" data-target="#comment_<?=$value['id']?>">Comment</a><br>
            </li>
          </ul>
        </div>
       </div>
    </div>


<div class="modal fade" id="comment_<?=$value['id']?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Your email & comment please</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="col-md-12">
          <label>Email</label>
          <input type="email" id="email_com_<?=$value['id']?>" class="form-control" name="email" placeholder="your email here">
        </div>
        <div class="col-md-12">
          <label>Comment</label>
          <input type="text" class="form-control" id="comments_<?=$value['id']?>" name="comment" placeholder="your comment here">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" id="<?= $value['id']?>" class="btn btn-outline-primary save_comment">Save</button>
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="like_<?=$value['id']?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Your email please</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="col-md-12">
          <input type="text" class="form-control" id="email_<?= $value['id']?>" name="email" placeholder="your email here">
        </div>
        <font class="text-danger email_error"></font>
      </div>
      <div class="modal-footer">
        <button type="button" id="<?= $value['id']?>" class="btn btn-outline-primary save_like">Save</button>
      </div>
    </div>
  </div>
</div>


<?php $i++; } ?>
  </div>
</div>
</body>
</html>




<!-- jQuery -->
<script src="<?= base_url()?>assets/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?= base_url()?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?= base_url()?>assets/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->



<script>
  $(document).ready(function () {
  	$("#message").delay("slow").fadeOut(3000);
    get_like()
   });

  function get_like(){
  	var all_article=$('#all_article').val()
  	for (var i = 0; i < all_article.length; i++) {
  		var id=$('#hidden_data_'+[i]).val()
  		$.ajax({
		url: "<?php echo base_url('Home/fetch_data'); ?>",
		type: "POST",
		data: {id_for_article:id_for_article},
		success: function(data){
			$('#total_like').html(data); 
		}
	});
  	}
 //  	$.ajax({
	// 	url: "<?php echo base_url('Home/fetch_data'); ?>",
	// 	type: "POST",
	// 	data: {id_for_article:id_for_article},
	// 	success: function(data){
	// 		$('#total_like').html(data); 
	// 	}
	// });
  }
</script>

<script>
	$('.save_like').on('click',function(){
	   var id_for_article=$(this).attr('id')
	   var email=$('#email_'+id_for_article).val()

	   if (email!='') {
	   	$('.email_error').html('')
	   	$.ajax({
	   	  url:'<?= base_url()?>Home/save_like',
	   	  type:'post',
	   	  data:{email:email,id_for_article:id_for_article},
	   	  success:function(data){
	   	  	// if (data=='false') {
	   	  	  $('#email_'+id_for_article).modal('hide')
              document.getElementById('message_like').style.display='block';
	   	  	// }
	   	  }
	   	})
	   }else{
	   	$('.email_error').html('required')
	   }
	})

  $('.save_comment').on('click',function(){
	   var id_for_article=$(this).attr('id')
	   var email=$('#email_com_'+id_for_article).val()
	   var comment=$('#comments_'+id_for_article).val()

// alert(comment,email)

	   if (email!='' && comment!='') {
	   	$('.email_error').html('')
	   	$.ajax({
	   	  url:'<?= base_url()?>Home/save_comment',
	   	  type:'post',
	   	  data:{email:email,id_for_article:id_for_article,comment:comment},
	   	  success:function(data){
	   	  	// if (data=='false') {
	   	  	  $('#email_'+id_for_article).modal('hide')
              document.getElementById('message_like').style.display='block';
	   	  	// }
	   	  }
	   	})
	   }else{
	   	$('.email_error').html('required')
	   }
	})
</script>                                                      