<?php

  include VIEWPATH.'template/include/Admin_Header.php'

?>

<style type="text/css">
	.navbar {		
		background: #fff;
		padding-left: 16px;
		padding-right: 16px;
		border-bottom: 1px solid #d6d6d6;
		box-shadow: 0 0 4px rgba(0,0,0,.1);
	}
</style>

</head> 
<body>
<nav class="navbar navbar-default navbar-expand-xl navbar-light">
	<div class="navbar-header d-flex col">
		<a class="navbar-brand" href="#"><i class="fa fa-cube"></i>Blog <b>niyodon</b></a>  		
		<button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle navbar-toggler ml-auto">
			<span class="navbar-toggler-icon"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
	</div>
	<div id="navbarCollapse" class="collapse navbar-collapse justify-content-start">
		<ul class="nav navbar-nav">
			<li class="nav-item active"><a href="<?= base_url()?>" class="nav-link">Home</a></li>
			<li class="nav-item"><a href="#" class="nav-link">About</a></li>
			<li class="nav-item"><a href="#" class="nav-link">Blog</a></li>
			<li class="nav-item"><a href="#" class="nav-link">Contact</a></li>
		</ul>
	</div>
</nav>



<!-- ####################< content >################# -->
<div class="conainer">
  <div class="col-md-12" id="message_like" style="display:none;">
  	<div class="alert alert-danger text-center" id ="message">vous ne pouvez pas aimer plus de une fois sur le meme article.</div>
  </div>
  <div class="row col-md-12 mt-5" id="data_article">
<input type="hidden" id="test_un">
  </div>
</div>
</body>
</html>




<!-- jQuery -->
<script src="<?= base_url()?>assets/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?= base_url()?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?= base_url()?>assets/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->



<script>
  $(document).ready(function(){
  	$("#message").delay("slow").fadeOut(3000);
  })
  $(document).ready(function () {
    get_data()
   });
  function get_data(){
  	$.ajax({
		url: "<?php echo base_url('Home/fetch_data'); ?>",
		type: "POST",
		cache: false,
		success: function(data){
			$('#data_article').html(data); 
		}
	});
  }

  function update_data(id_for_article){
	var id_for_article=id_for_article
	   var email=$('#email_'+id_for_article).val()

	   if (email!='') {
	   	$('.email_error').html('')
	   	$.ajax({
	   	  url:'<?= base_url()?>Home/save_like',
	   	  type:'post',
	   	  data:{email:email,id_for_article:id_for_article},
	   	  success:function(data){
	   	  	 if (data==1) {
	   	  	  	$('#like_'+id_for_article).modal('hide')
	   	  	  	$('#email_'+id_for_article).html('')
	   	  	  	get_data()

	   	  	  }else{
	   	  	  	$('#like_'+id_for_article).modal('hide')
	   	  	  	$('#email_'+id_for_article).html('')
	   	  	  	alert('you may not like more than one on the same article')
	   	  	  //document.getElementById('message_like').style.display='block';
	   	  	  }
	   	  }
	   	})
	   }else{
	   	$('.email_error').html('required')
	   }
}
</script>

<script>


function save_com(id_for_article){
  var id_for_article=id_for_article
	   var email=$('#email_com_'+id_for_article).val()
	   var comment=$('#comments_'+id_for_article).val()

	   if (email!='' && comment!='') {
	   	$('.email_error').html('')
	   	$.ajax({
	   	  url:'<?= base_url()?>Home/save_comment',
	   	  type:'post',
	   	  data:{email:email,id_for_article:id_for_article,comment:comment},
	   	  success:function(data){
	   	  	  if (data==1) {
	   	  	  	$('#comment_'+id_for_article).modal('hide')
	   	  	  $('#comments_'+id_for_article).html('')
	   	  	  $('#email_com_'+id_for_article).html('')
              get_data()
          }else{
          	  $('#comment_'+id_for_article).modal('hide')
          	  alert('you may not comment more than three on the same article')
              // document.getElementById('message_like').style.display='block';
          }
	   	  }
	   	})
	   }else{
	   	$('.email_error').html('required')
	   }	
}
 
</script>                                                      