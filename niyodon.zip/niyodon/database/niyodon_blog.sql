-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2021 at 12:26 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `niyodon_blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `id` int(11) NOT NULL,
  `id_for_categories` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `basic_description` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `visibility` tinyint(1) NOT NULL DEFAULT 1,
  `image` varchar(100) DEFAULT NULL,
  `folder` varchar(100) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'time_reated',
  `time_update` datetime DEFAULT NULL COMMENT 'time_update'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `id_for_categories`, `title`, `basic_description`, `description`, `visibility`, `image`, `folder`, `time`, `time_update`) VALUES
(2, 3, 'It is a long established fact that a reader', 'okay', '            <span style=\"color: rgb(0, 0, 0); font-family: \"Open Sans\", Arial, sans-serif; font-size: 14px; text-align: justify;\">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</span>          ', 1, '2021051611293560a0e5ff00e8d.jpg', '1621106398', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 3, 'Asus', '           test asus \r\n          ', '<span style=\"color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px; text-align: justify;\">There are many </span><span style=\"font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px; text-align: justify;\"><font color=\"#0000ff\">variations of passages of Lorem Ipsum available, but th</font></span><span style=\"color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px; text-align: justify;\">e majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</span>', 1, '2021051608145160a0b85b6dd82.jpg', '1621145646', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 2, 'Lorem Ipsum is simply dummy text ok', '           <b><u>                                 Lorem Ipsum is simply dummy </u></b> \r\n          ', '                                                                        <strong style=\"margin: 0px; padding: 0px; color: rgb(0, 0, 0); font-family: \"Open Sans\", Arial, sans-serif; font-size: 14px; text-align: justify;\">Lorem Ipsum</strong><span style=\"color: rgb(0, 0, 0); font-family: \"Open Sans\", Arial, sans-serif; font-size: 14px; text-align: justify;\"> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</span>                                                            ', 1, '2021051611283060a0e5beb5eef.jpg', '1621146221', '0000-00-00 00:00:00', '2021-05-16 12:07:24'),
(7, 3, 'Contrary to popular belief, Lorem Ipsum is not simply random text.', '<span style=\"color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: ', '<span style=\"color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px; text-align: justify;\">Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</span>                      ', 1, '2021051612085060a0ef32b6f87.jpg', '1621159681', '2021-05-16 10:08:50', NULL),
(8, 1, 'Lorem Ipsum is simply dummy text of the printing', '           test \r\n          ', '            <span style=\"color: rgb(0, 0, 0);\">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</span>          ', 1, '2021051612132060a0f040e20b4.jpg', '1621159967', '2021-05-16 10:13:20', '2021-05-16 12:14:29'),
(9, 3, 'It is a long established fact that a reader will be ', 'okay', '<span style=\"color: rgb(0, 0, 0);\">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</span>                      ', 1, '2021051612134960a0f05de979f.jpg', '1621160003', '2021-05-16 10:13:49', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `categorie_id` int(11) NOT NULL,
  `categorie_descr` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`categorie_id`, `categorie_descr`) VALUES
(1, 'Love'),
(2, 'Musics'),
(3, 'History');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `id_for_article` int(11) NOT NULL,
  `time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `comment`, `email`, `id_for_article`, `time`) VALUES
(1, 'okkkk', 'uyc.tic@gmail.com', 2, '2021-05-16 11:37:36'),
(2, 'okkkk', 'uyc.tic@gmail.com', 2, '2021-05-16 11:37:48'),
(3, 'thx', 'niyodonpaci@gmail.com', 6, '2021-05-16 11:39:12'),
(4, 'test', 'niyodonpaci@gmail.com', 6, '2021-05-16 12:03:20'),
(5, 'test', 'uyc.tic@gmail.com', 6, '2021-05-16 12:03:31'),
(6, 'test', 'niyodonpaci@gmail.com', 6, '2021-05-16 12:03:43');

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `id` int(11) NOT NULL,
  `total_like` int(11) NOT NULL,
  `id_for_article` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`id`, `total_like`, `id_for_article`, `user_name`, `time`) VALUES
(1, 1, 2, 'niyodonpaci@gmail.com', '2021-05-16 09:37:17'),
(2, 1, 2, 'ntirampebajeandedieu@gmail.com', '2021-05-16 09:37:25'),
(3, 1, 5, 'puneethreddy951@gmail.com', '2021-05-16 09:37:57'),
(4, 1, 5, 'kamatari@gmail.com', '2021-05-16 09:38:18'),
(5, 1, 6, 'niyodonpaci@gmail.com', '2021-05-16 09:38:30'),
(6, 1, 6, 'uyc.tic@gmail.com', '2021-05-16 09:38:38'),
(7, 1, 6, 'ntirampebajeandedieu@gmail.com', '2021-05-16 09:38:47'),
(8, 1, 6, 'kamatari@gmail.com', '2021-05-16 09:38:55'),
(9, 1, 6, 'kamatari5@gmail.com', '2021-05-16 10:03:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`categorie_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `categorie_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
